ALTER TABLE public.contract ADD contract_code varchar NOT NULL DEFAULT '';
