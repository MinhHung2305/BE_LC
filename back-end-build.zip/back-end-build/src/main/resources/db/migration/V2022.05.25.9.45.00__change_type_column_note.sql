ALTER TABLE public.character_set ALTER COLUMN note DROP NOT NULL;
