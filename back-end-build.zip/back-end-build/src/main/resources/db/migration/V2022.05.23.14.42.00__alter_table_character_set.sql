ALTER TABLE public.electric_type ALTER COLUMN proposal DROP NOT NULL;
