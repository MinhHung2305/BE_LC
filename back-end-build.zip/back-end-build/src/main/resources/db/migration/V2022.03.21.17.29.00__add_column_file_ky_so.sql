ALTER TABLE public.application_opening_lc ADD file_ky_so varchar(255) NULL;
