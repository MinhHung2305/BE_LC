ALTER TABLE public.financing_limit ADD financing_limit_code varchar(255) NULL;
