ALTER TABLE public.product DROP CONSTRAINT "FK_contract_id";
