ALTER TABLE public.application_opening_lc ADD reason_for_refusal varchar(255) NULL;
