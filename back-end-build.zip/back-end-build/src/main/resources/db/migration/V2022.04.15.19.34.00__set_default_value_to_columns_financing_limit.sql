ALTER TABLE public.financing_limit ALTER COLUMN total_zoning_limit SET DEFAULT 0;
ALTER TABLE public.financing_limit ALTER COLUMN total_commitment_limit SET DEFAULT 0;
ALTER TABLE public.financing_limit ALTER COLUMN total_disbursement_amount SET DEFAULT 0;
ALTER TABLE public.financing_limit ALTER COLUMN total_repayment_amount SET DEFAULT 0;
ALTER TABLE public.financing_limit ALTER COLUMN availability_limit SET DEFAULT 0;
