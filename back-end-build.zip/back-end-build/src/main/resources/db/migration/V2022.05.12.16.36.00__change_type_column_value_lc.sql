ALTER TABLE public.application_opening_lc ALTER COLUMN value_lc TYPE bigint USING value_lc::bigint;
