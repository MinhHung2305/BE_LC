ALTER TABLE IF EXISTS public.contract
    ADD COLUMN bank_account_id integer;