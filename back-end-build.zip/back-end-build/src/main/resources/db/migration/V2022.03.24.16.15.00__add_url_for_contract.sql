ALTER TABLE IF EXISTS public.contract
    ADD COLUMN url_minio character varying;