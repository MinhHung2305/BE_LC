ALTER TABLE public.application_opening_lc ALTER COLUMN period_for_presentation TYPE varchar USING period_for_presentation::varchar;
