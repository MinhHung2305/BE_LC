ALTER TABLE IF EXISTS public.bank_rating
    ADD COLUMN status integer NOT NULL Default 0;