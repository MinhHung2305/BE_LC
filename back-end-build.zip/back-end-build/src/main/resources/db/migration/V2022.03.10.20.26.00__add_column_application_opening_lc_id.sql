ALTER TABLE public.product ADD application_opening_lc_id bigint NULL;
