ALTER TABLE public.electric_type ADD swift_version varchar NULL;
COMMENT ON COLUMN public.electric_type.swift_version IS 'phien ban swift tham chieu';
