ALTER TABLE public.financing_limit ADD status int4 NULL;
