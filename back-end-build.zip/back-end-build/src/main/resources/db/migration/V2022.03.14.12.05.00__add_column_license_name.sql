ALTER TABLE public.license ADD license_name varchar(255) NULL;
