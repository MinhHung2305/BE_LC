ALTER TABLE public.contract ADD base64_file varchar NULL;
