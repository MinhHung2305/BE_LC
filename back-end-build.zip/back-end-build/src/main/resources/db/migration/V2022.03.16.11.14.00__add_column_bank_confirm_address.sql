ALTER TABLE public.application_opening_lc ADD bank_confirm_address varchar(255) NULL;
