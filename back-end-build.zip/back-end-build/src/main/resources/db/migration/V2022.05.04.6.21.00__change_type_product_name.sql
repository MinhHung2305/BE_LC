ALTER TABLE public.product_type ALTER COLUMN product_name TYPE text USING product_name::text;
