ALTER TABLE public.application_opening_lc ADD status int NULL;
