ALTER TABLE public.financing_limit_change_history DROP COLUMN times_change;
