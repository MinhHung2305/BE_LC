package fis.com.vn.repository.admin;

import fis.com.vn.model.entity.ElectricType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ElectricTypeRepository extends JpaRepository<ElectricType, Long> {
}
