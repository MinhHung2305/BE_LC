package fis.com.vn.repository.admin;

import fis.com.vn.model.entity.CharacterSetElectricType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CharacterSetElectricTypeRepository extends JpaRepository<CharacterSetElectricType, Long> {
}
