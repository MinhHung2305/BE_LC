package fis.com.vn.service.admin;

import fis.com.vn.rest.response.CommodityResponse;

import java.util.List;

public interface CommodityService {
    public List<CommodityResponse> getAllCommodity();
}
