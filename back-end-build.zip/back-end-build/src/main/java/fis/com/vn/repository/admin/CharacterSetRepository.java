package fis.com.vn.repository.admin;

import fis.com.vn.model.entity.CharacterSet;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CharacterSetRepository extends JpaRepository<CharacterSet, Long> {
}
