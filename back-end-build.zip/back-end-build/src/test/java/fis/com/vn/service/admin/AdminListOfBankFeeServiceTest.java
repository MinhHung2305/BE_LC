package fis.com.vn.service.admin;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("local")
class AdminListOfBankFeeServiceTest {
}