package fis.com.vn.service.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("local")
class AdminListOfBankFeeRulesServiceTest {

    @Test
    void getAlListOfBankFee() {

    }

    @Test
    void getDetailBankFee() {
    }

    @Test
    void createRecordBankFee() {
    }

    @Test
    void updateRecordBankFee() {
    }

    @Test
    void deleteRecordBankFee() {
    }
}